import { chromium } from "playwright";
import { readFileSync } from "node:fs";
const html = readFileSync("dist/index.html", "utf8");
const browser = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium" });
const page = await browser.newPage({ viewport: { width: 1000, height: 700 } });
page.on("pageerror", (e) => console.log("PAGE ERROR:", e.message));
await page.setContent(html);
await page.waitForFunction(() => !!window.game);

const r = await page.evaluate(async () => {
  const g = window.game;
  g.settingsForTest.nomad = false;
  // Pin the map: this asserts against specific tiles and the game picks a random
  // map per match. An unpinned run put the test hall on water and reported the
  // King as unable to found one.
  g.settingsForTest.mapId = "lakeland-7927";
  // Classic start: this test is not about the crowning opening.
  g.settingsForTest.crowning = false;
  g.start("none");
  const w = g.world, P = 1;
  const out = {};
  const step = (n) => { for (let i = 0; i < n; i++) g.tick(); };
  const mine = (def) => w.units().filter((u) => u.owner === P && u.def === def);

  out.kingsAtStart = mine("king").length;

  // A peasant may not found a hall.
  w.players.get(P).gold = 99999;
  w.players.get(P).lumber = 99999;
  // Find ground the game itself agrees is buildable, rather than hoping a
  // hard-coded tile is clear.
  const siteFor = (from) => {
    for (let r = 4; r < 26; r++)
      for (let i = 0; i < r * 8; i++) {
        const a = (i / (r * 8)) * Math.PI * 2;
        const x = from[0] + Math.round(Math.cos(a) * r);
        const y = from[1] + Math.round(Math.sin(a) * r);
        if (w.placementError(P, "townhall", x, y) === null) return [x, y];
      }
    return null;
  };
  const home = w.map.starts[0];
  const site = siteFor([home.x, home.y]);
  out.foundSite = site;

  const peasant = mine("worker")[0];
  const before = w.buildings().filter((b) => b.owner === P).length;
  g.issue({ type: "build", player: P, units: [peasant.id], building: "townhall", tx: site[0], ty: site[1] });
  step(3);
  out.peasantFoundedHall = w.buildings().filter((b) => b.owner === P).length > before;
  out.refusalShown = w.events.concat([]).length >= 0;

  // The King may.
  const king = mine("king")[0];
  g.issue({ type: "build", player: P, units: [king.id], building: "townhall", tx: site[0], ty: site[1] });
  step(3);
  out.kingFoundedHall = w.buildings().some((b) => b.owner === P && b.tx === site[0] && b.ty === site[1]);

  // Heirs cost three supply each, so without room to feed them the cap is never
  // the thing being tested.
  for (let i = 0; i < 4; i++) {
    const f = siteFor([home.x, home.y]);
    if (f) w.placeBuilding(P, "farm", f[0], f[1], true);
  }

  // Heirs are trained at the hall, and rationed.
  const hall = w.buildings().find((b) => b.owner === P && b.def === "townhall" && b.complete);
  for (let i = 0; i < 6; i++) { g.issue({ type: "train", player: P, building: hall.id, unit: "prince" }); step(2); }
  step(20 * 60 * 6);
  out.princes = mine("prince").length;

  // Succession: kill the King and the eldest heir takes the crown.
  const oldKing = mine("king")[0];
  const heirIds = mine("prince").map((u) => u.id).sort((a, b) => a - b);
  w.removeEntity(oldKing.id);
  out.newKingIsEldestHeir = mine("king")[0]?.id === heirIds[0];
  out.princesAfter = mine("prince").length;

  // With no royalty left, no new capital may be founded.
  for (const u of [...mine("king"), ...mine("prince")]) w.removeEntity(u.id);
  const n = w.buildings().filter((b) => b.owner === P).length;
  const peasant2 = mine("worker")[0];
  const site2 = siteFor([home.x, home.y]);
  g.issue({ type: "build", player: P, units: [peasant2.id], building: "townhall", tx: site2[0], ty: site2[1] });
  step(3);
  out.foundedWithNoRoyals = w.buildings().filter((b) => b.owner === P).length > n;
  return out;
});
console.log(JSON.stringify(r, null, 1));
if (r.kingsAtStart !== 1) throw new Error("you should start with exactly one King");
if (r.peasantFoundedHall) throw new Error("a peasant founded a Town Hall");
if (!r.kingFoundedHall) throw new Error("the King could not found a Town Hall");
if (r.princes !== 3) throw new Error(`expected 3 princes (the cap), got ${r.princes}`);
if (!r.newKingIsEldestHeir) throw new Error("the crown did not pass to the eldest heir");
if (r.foundedWithNoRoyals) throw new Error("a hall was founded with no royalty alive");
console.log("the royal line holds");
await browser.close();
