import { chromium } from "playwright";
import { readFileSync } from "node:fs";
const html = readFileSync("dist/index.html", "utf8");
const browser = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium" });
const page = await browser.newPage({ viewport: { width: 1100, height: 700 } });
page.on("pageerror", (e) => console.log("PAGE ERROR:", e.message));
await page.setContent(html);
await page.waitForFunction(() => !!window.game);

// Four halls at four levels of damage, so the fire can be seen growing.
await page.evaluate(() => {
  const g = window.game;
  g.settingsForTest.nomad = false;
  // Classic start: this test is not about the crowning opening.
  g.settingsForTest.crowning = false;
  g.start("none");
  const w = g.world, SUB = 64;
  for (const b of [...w.buildings()]) w.removeEntity(b.id);
  for (const u of [...w.units()]) w.removeEntity(u.id);
  for (let y = 10; y < 30; y++) for (let x = 6; x < 46; x++) w.map.set(x, y, 0);
  for (let i = 0; i < 4; i++) w.placeBuilding(1, "barracks", 9 + i * 8, 16, true);
  g.cam.zoom = 38;
  g.cam.centerOn(21 * SUB, 17 * SUB);
});
await page.waitForTimeout(700);

// The fire is painted, so count warm pixels to prove it is there.
//
// Sampling a box over each building was too clever: it depended on toScreen,
// the zoom and the camera clamp all agreeing across two separate evaluates, and
// when the board grew to 160 tiles it silently sampled empty grass and reported
// no fire at all while the screen plainly showed four burning barracks. Counting
// the whole canvas twice -- once healthy, once wrecked -- tests the same thing
// and cannot drift.
const warmPixels = () =>
  page.evaluate(() => {
    const g = window.game;
    const ctx = g.canvas.getContext("2d");
    const d = ctx.getImageData(0, 0, g.canvas.width, Math.round(g.canvas.height * 0.6)).data;
    let hot = 0;
    for (let j = 0; j < d.length; j += 4) {
      if (d[j] > 180 && d[j] > d[j + 2] + 70 && d[j + 1] > 80) hot++;
    }
    return hot;
  });

const healthy = await warmPixels();
await page.evaluate(() => {
  const w = window.game.world;
  for (const b of w.buildings()) b.hp = Math.max(1, Math.round(b.maxHp * 0.08));
});
await page.waitForTimeout(600);
const wrecked = await warmPixels();
console.log(`warm pixels: ${healthy} with every building whole, ${wrecked} with every building nearly dead`);
if (wrecked < healthy * 4 || wrecked < 500) throw new Error("damaged buildings are not burning");

await page.evaluate(() => { window.game.paused = true; });
await page.waitForTimeout(300);
await page.screenshot({ path: "test/shot-fire.png", clip: { x: 0, y: 0, width: 1100, height: 430 } });
await browser.close();
