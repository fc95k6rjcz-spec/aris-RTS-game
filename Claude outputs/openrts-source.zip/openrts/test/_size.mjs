import { chromium } from "playwright";
import { readFileSync } from "node:fs";
const browser = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium" });
const page = await browser.newPage({ viewport: { width: 900, height: 600 } });
page.on("pageerror", (e) => console.log("PAGE ERROR:", e.message));
await page.setContent(readFileSync("dist/index.html", "utf8"));
await page.waitForFunction(() => !!window.rts);
const out = await page.evaluate(() => {
  const { GameMap } = window.rts;
  const res = [];
  for (const n of [64, 128, 160, 192, 256]) {
    const t0 = performance.now();
    const m = GameMap.generate(n, n, 4242, "lakeland");
    const gen = performance.now() - t0;
    // Can a terrain canvas that size even be allocated at 40px a tile?
    let bake = null, err = null;
    try {
      const c = document.createElement("canvas");
      c.width = n * 40; c.height = n * 40;
      const g = c.getContext("2d");
      g.fillStyle = "#123"; g.fillRect(0, 0, 50, 50);
      const px = g.getImageData(10, 10, 1, 1).data;
      bake = px[3] === 255 ? `${c.width}px ok` : `${c.width}px BLANK`;
    } catch (e) { err = String(e); }
    res.push({ n, tiles: n * n, genMs: +gen.toFixed(1), canvas: bake, err });
  }
  return res;
});
for (const r of out) console.log(`${r.n}x${r.n} (${r.tiles} tiles): generate ${r.genMs}ms, terrain canvas ${r.canvas ?? r.err}`);
await browser.close();
