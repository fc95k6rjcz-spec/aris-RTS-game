import { chromium } from "playwright";
import { readFileSync } from "node:fs";
const html = readFileSync("dist/index.html", "utf8");
const browser = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium" });
const page = await browser.newPage({ viewport: { width: 1000, height: 700 } });
page.on("pageerror", (e) => console.log("PAGE ERROR:", e.message));
await page.setContent(html);
await page.waitForFunction(() => !!window.game);
await page.evaluate(() => window.game.start("none"));

const ticks = () => page.evaluate(() => window.game.world.tick);
const ran = async (ms) => { const a = await ticks(); await page.waitForTimeout(ms); return (await ticks()) - a; };

if ((await ran(500)) === 0) throw new Error("game was not running to begin with");

// The button.
await page.click(".rts-pause");
if ((await ran(500)) !== 0) throw new Error("button did not pause");
console.log("button pauses");
await page.screenshot({ path: "test/shot-paused.png" });

await page.click(".rts-pause");
if ((await ran(500)) === 0) throw new Error("button did not resume");
console.log("button resumes");

// The space bar, and the button must follow it.
await page.keyboard.press("Space");
if ((await ran(400)) !== 0) throw new Error("space did not pause");
let label = await page.getAttribute(".rts-pause", "aria-pressed");
if (label !== "true") throw new Error(`button out of step after key: ${label}`);
console.log("space pauses and the button follows");

// A direct write to the field must still show, since the tests do that.
await page.evaluate(() => { window.game.paused = false; });
await page.waitForTimeout(200);
label = await page.getAttribute(".rts-pause", "aria-pressed");
if (label !== "false") throw new Error(`button out of step after direct write: ${label}`);
console.log("button follows a direct write to the field");

// Resuming must not spend the paused time all at once.
await page.evaluate(() => window.game.setPaused(true));
await page.waitForTimeout(1500);
const before = await ticks();
await page.evaluate(() => window.game.setPaused(false));
await page.waitForTimeout(120);
const jump = (await ticks()) - before;
console.log(`ticks in the first 120ms after a 1.5s pause: ${jump}`);
if (jump > 12) throw new Error(`resume lurched forward by ${jump} ticks`);
await browser.close();
