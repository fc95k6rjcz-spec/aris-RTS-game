import { chromium } from "playwright";
import { readFileSync } from "node:fs";
const html = readFileSync("dist/index.html", "utf8");
const browser = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium" });
const page = await browser.newPage({ viewport: { width: 900, height: 600 } });
page.on("pageerror", (e) => console.log("PAGE ERROR:", e.message));
await page.setContent(html);
await page.waitForFunction(() => !!window.game);

/** How many ticks a worker and a barracks take to appear, at a given pace. */
async function timings(pace) {
  return await page.evaluate((pace) => {
    const g = window.game;
    g.settingsForTest.pace = pace;
    g.settingsForTest.mapId = "lakeland-7927";
    g.settingsForTest.nomad = false;
    // Classic start: this test is not about the crowning opening.
    g.settingsForTest.crowning = false;
    g.start("none");
    const w = g.world, P = 1;
    w.players.get(P).gold = 99999;
    w.players.get(P).lumber = 99999;
    const hall = w.buildings().find((b) => b.owner === P && b.def === "townhall");
    const before = w.units().filter((u) => u.owner === P && u.def === "worker").length;
    g.issue({ type: "train", player: P, building: hall.id, unit: "worker" });
    let trained = null;
    for (let t = 0; t < 20000 && trained === null; t++) {
      g.tick();
      if (w.units().filter((u) => u.owner === P && u.def === "worker").length > before) trained = w.tick;
    }
    return { pace: w.pace, trained };
  }, pace);
}

const one = await timings(1);
const four = await timings(4);
console.log(`a worker takes ${one.trained} ticks at pace ${one.pace}, ${four.trained} at pace ${four.pace}`);
const ratio = four.trained / one.trained;
console.log(`ratio ${ratio.toFixed(2)} (expected about 4)`);
if (ratio < 3.4 || ratio > 4.6) throw new Error(`pace did not stretch the clock as asked: ${ratio.toFixed(2)}x`);
await browser.close();
